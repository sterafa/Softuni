﻿using NUnit.Framework;

namespace TestApp.Tests;

[TestFixture]
public class StringModifierTests
{
    [Test]
    public void Test_Modify_EmptyString_ReturnsEmptyString()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Modify_SingleWordWithEvenLength_ReturnsUppperCaseWord()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Modify_SingleWordWithOddLength_ReturnsToLowerCaseWord()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Modify_MultipleWords_ReturnsModifiedString()
    {
        // TODO: finish the test
    }
}

