using System.Collections.Generic;

using NUnit.Framework;

namespace TestApp.Tests;

[TestFixture]
public class NumberFrequencyTests
{
    [Test]
    public void Test_CountDigits_ZeroNumber_ReturnsEmptyDictionary()
    {
        // Arrange
        int number = 0;

        // Act
        Dictionary<int, int> result = NumberFrequency.CountDigits(number);

        // Assert
        Assert.That(result, Is.Empty);
    }

    [Test]
    public void Test_CountDigits_PositiveSingleDigitNumber_ReturnsDictionaryWithSingleEntry()
    {
        // Arrange
        int number = 7;

        // Act
        Dictionary<int, int> result = NumberFrequency.CountDigits(number);

        // Assert
        Assert.That(result.Count, Is.EqualTo(1));
        Assert.That(result[7], Is.EqualTo(1));
    }

    [Test]
    public void Test_CountDigits_PositiveMultipleDigitNumber_ReturnsDictionaryWithDigitFrequencies()
    {
        // Arrange
        int number = 1223334444;

        // Act
        Dictionary<int, int> result = NumberFrequency.CountDigits(number);

        // Assert
        Assert.That(result.Count, Is.EqualTo(4));
        Assert.That(result[1], Is.EqualTo(1));
        Assert.That(result[2], Is.EqualTo(2));
        Assert.That(result[3], Is.EqualTo(3));
        Assert.That(result[4], Is.EqualTo(4));
    }

    [Test]
    public void Test_CountDigits_NegativeSingleDigitNumber_ReturnsDictionaryWithSingleEntry()
    {
        // Arrange
        int number = -7;

        // Act
        Dictionary<int, int> result = NumberFrequency.CountDigits(number);

        // Assert
        Assert.That(result.Count, Is.EqualTo(1));
        Assert.That(result[7], Is.EqualTo(1));
    }

    [Test]
    public void Test_CountDigits_NegativeMultipleDigitNumber_ReturnsDictionaryWithDigitFrequencies()
    {
        // Arrange
        int number = -1223334444;

        // Act
        Dictionary<int, int> result = NumberFrequency.CountDigits(number);

        // Assert
        Assert.That(result.Count, Is.EqualTo(4));
        Assert.That(result[1], Is.EqualTo(1));
        Assert.That(result[2], Is.EqualTo(2));
        Assert.That(result[3], Is.EqualTo(3));
        Assert.That(result[4], Is.EqualTo(4));
    }

    [Test]
    public void Test_CountDigits_LargePositiveNumber_ReturnsDictionaryWithDigitFrequencies()
    {
        // Arrange
        int number = 987654321;

        // Act
        Dictionary<int, int> result = NumberFrequency.CountDigits(number);

        // Assert
        Assert.That(result.Count, Is.EqualTo(9));
        Assert.That(result[1], Is.EqualTo(1));
        Assert.That(result[2], Is.EqualTo(1));
        Assert.That(result[3], Is.EqualTo(1));
        Assert.That(result[4], Is.EqualTo(1));
        Assert.That(result[5], Is.EqualTo(1));
        Assert.That(result[6], Is.EqualTo(1));
        Assert.That(result[7], Is.EqualTo(1));
        Assert.That(result[8], Is.EqualTo(1));
        Assert.That(result[9], Is.EqualTo(1));
    }

    [Test]
    public void Test_CountDigits_LargeNegativeNumber_ReturnsDictionaryWithDigitFrequencies()
    {
        // Arrange
        int number = -987654321;

        // Act
        Dictionary<int, int> result = NumberFrequency.CountDigits(number);

        // Assert
        Assert.That(result.Count, Is.EqualTo(9));
        Assert.That(result[1], Is.EqualTo(1));
        Assert.That(result[2], Is.EqualTo(1));
        Assert.That(result[3], Is.EqualTo(1));
        Assert.That(result[4], Is.EqualTo(1));
        Assert.That(result[5], Is.EqualTo(1));
        Assert.That(result[6], Is.EqualTo(1));
        Assert.That(result[7], Is.EqualTo(1));
        Assert.That(result[8], Is.EqualTo(1));
        Assert.That(result[9], Is.EqualTo(1));
    }
}
